#!/bin/bash
mkdir -p checkpoints
python -u train.pyc --name piv_particle_vidme --stage particle --validation particle --gpus 0 --num_steps 400000 --batch_size 8 --lr 0.000125 --image_size 256 256 --wdecay 0.0001 --mixed_precision
#python -u train.py --name piv_particle_vidme --stage particle --validation particle --gpus 0 --num_steps 400000 --batch_size 8 --lr 0.000125 --image_size 256 256 --wdecay 0.0001 --mixed_precision
